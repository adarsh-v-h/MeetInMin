const elements = {
  statusText: document.querySelector("#statusText"),
  durationText: document.querySelector("#durationText"),
  formatText: document.querySelector("#formatText"),
  sizeText: document.querySelector("#sizeText"),
  messageText: document.querySelector("#messageText"),
  startButton: document.querySelector("#startButton"),
  pauseButton: document.querySelector("#pauseButton"),
  resumeButton: document.querySelector("#resumeButton"),
  stopButton: document.querySelector("#stopButton"),
  downloadButton: document.querySelector("#downloadButton"),
  apiKeySelect: document.querySelector("#apiKeySelect"),
  newApiKeyNameInput: document.querySelector("#newApiKeyNameInput"),
  newApiKeyInput: document.querySelector("#newApiKeyInput"),
  addApiKeyBtn: document.querySelector("#addApiKeyBtn"),
};

let currentStatus = {
  state: "idle",
  durationMs: 0,
  bytes: 0,
  mimeType: "audio/webm;codecs=opus",
  error: "",
};

document.addEventListener("DOMContentLoaded", init);

function init() {
  localizeDocument();
  elements.startButton.addEventListener("click", handleStart);
  elements.pauseButton.addEventListener("click", () => sendCommand("PAUSE_RECORDING"));
  elements.resumeButton.addEventListener("click", () => sendCommand("RESUME_RECORDING"));
  elements.stopButton.addEventListener("click", () => sendCommand("STOP_RECORDING"));
  if (elements.downloadButton) {
    elements.downloadButton.addEventListener("click", () => sendCommand("DOWNLOAD_LOCAL"));
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (!message || message.target !== "popup") {
      return;
    }

    if (message.status) {
      renderStatus(message.status);
    }
  });

  
  loadApiKeys();
  elements.addApiKeyBtn.addEventListener("click", async () => {
    const val = elements.newApiKeyInput.value.trim();
    const nameVal = elements.newApiKeyNameInput.value.trim() || "My Key";
    if (!val) return;
    const data = await chrome.storage.local.get(["apiKeys"]);
    const keys = data.apiKeys || [];
    
    // Support migrating old string arrays to object arrays
    const formattedKeys = keys.map(k => typeof k === "string" ? { name: "Old Key", key: k } : k);
    
    if (!formattedKeys.find(k => k.key === val)) {
      formattedKeys.push({ name: nameVal, key: val });
      await chrome.storage.local.set({ apiKeys: formattedKeys, activeApiKey: val });
    }
    elements.newApiKeyInput.value = "";
    elements.newApiKeyNameInput.value = "";
    await loadApiKeys();
  });
  elements.apiKeySelect.addEventListener("change", async () => {
    await chrome.storage.local.set({ activeApiKey: elements.apiKeySelect.value });
  });

  sendCommand("GET_STATUS", {}, { silent: true }).catch(() => {});
}

async function handleStart() {
  const includeMic = document.querySelector("#micCheckbox").checked;
  
  if (includeMic) {
    try {
      const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStream.getTracks().forEach((t) => t.stop());
    } catch (e) {
      chrome.tabs.create({ url: chrome.runtime.getURL("src/pages/permission/permission.html") });
      renderStatus({
        ...currentStatus,
        state: "error",
        error: t("errorMicPermission"),
      });
      return;
    }
  }
  
  sendCommand("START_RECORDING", { recordMic: includeMic });
}

async function sendCommand(type, payload = {}, options = {}) {
  setControlsDisabled(true);

  if (!options.silent) {
    elements.messageText.textContent = "";
  }

  try {
    const response = await chrome.runtime.sendMessage({ target: "worker", type, ...payload });
    if (!response?.ok) {
      throw new Error(response?.error || t("errorCommandFailed"));
    }

    renderStatus(response.status || currentStatus);
  } catch (error) {
    renderStatus({
      ...currentStatus,
      state: "error",
      error: error.message || t("errorCommandFailed"),
    });
  }
}

function renderStatus(status) {
  currentStatus = {
    ...currentStatus,
    ...status,
  };

  document.body.dataset.state = currentStatus.state;
  elements.statusText.textContent = getStatusText(currentStatus);
  elements.durationText.textContent = formatDuration(currentStatus.durationMs || 0);
  elements.formatText.textContent = formatMime(currentStatus.mimeType);
  elements.sizeText.textContent = formatBytes(currentStatus.bytes || 0);
  
  if (currentStatus.error) {
    elements.messageText.textContent = currentStatus.error;
    elements.messageText.style.color = "#ef4444";
  } else if (currentStatus.state === "saving") {
    elements.messageText.textContent = t("statusUploadingSafetyNotice");
    elements.messageText.style.color = "#3b82f6";
  } else if (currentStatus.state === "completed" && currentStatus.bytes > 0) {
    elements.messageText.textContent = t("statusUploadSuccessNotice");
    elements.messageText.style.color = "#10b981";
  } else {
    elements.messageText.textContent = "";
  }

  setButtonStates(currentStatus.state);
}

function setControlsDisabled(disabled) {
  Object.values(getControlVisibility(currentStatus.state)).forEach(({ element }) => {
    if (element) element.disabled = disabled;
  });
}

function setButtonStates(state) {
  const controls = getControlVisibility(state);
  Object.values(controls).forEach(({ element, visible, disabled }) => {
    if (element) {
      element.hidden = !visible;
      element.disabled = disabled;
    }
  });

  const micOptionContainer = document.querySelector("#micOptionContainer");
  if (micOptionContainer) {
    micOptionContainer.hidden = !["idle", "completed", "error"].includes(state);
  }
}

function getControlVisibility(state) {
  return {
    start: {
      element: elements.startButton,
      visible: ["idle", "completed", "error"].includes(state),
      disabled: !["idle", "completed", "error"].includes(state),
    },
    pause: {
      element: elements.pauseButton,
      visible: state === "recording",
      disabled: state !== "recording",
    },
    resume: {
      element: elements.resumeButton,
      visible: state === "paused",
      disabled: state !== "paused",
    },
    stop: {
      element: elements.stopButton,
      visible: ["recording", "paused", "preparing"].includes(state),
      disabled: !["recording", "paused"].includes(state),
    },
    download: {
      element: elements.downloadButton,
      visible: ["saving", "completed", "error"].includes(state) && currentStatus.bytes > 0,
      disabled: false,
    },
  };
}

function getStatusText(status) {
  switch (status.state) {
    case "preparing":
      return t("statusPreparing");
    case "recording":
      return t("statusRecording", [formatDuration(status.durationMs || 0)]);
    case "paused":
      return t("statusPaused");
    case "saving":
      return t("statusUploading");
    case "completed":
      return t("statusCompleted");
    case "error":
      return t("statusError");
    case "idle":
    default:
      return t("statusIdle");
  }
}

function formatMime(mimeType) {
  if (!mimeType) {
    return t("formatOpusWebm");
  }

  if (mimeType.includes("opus")) {
    return t("formatOpusWebm");
  }

  return t("formatWebm");
}

function formatDuration(durationMs) {
  const totalSeconds = Math.floor(durationMs / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return [hours, minutes, seconds].map((value) => String(value).padStart(2, "0")).join(":");
}

function formatBytes(bytes) {
  if (!bytes) {
    return "0 B";
  }

  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let unitIndex = 0;

  while (value >= 1024 && unitIndex < units.length - 1) {
    value /= 1024;
    unitIndex += 1;
  }

  const fractionDigits = value >= 10 || unitIndex === 0 ? 0 : 1;
  return `${value.toFixed(fractionDigits)} ${units[unitIndex]}`;
}

function localizeDocument() {
  document.documentElement.lang = chrome.i18n.getUILanguage?.() || navigator.language || "en";
  document.title = t("extensionName");

  document.querySelectorAll("[data-i18n]").forEach((node) => {
    node.textContent = t(node.dataset.i18n);
  });

  document.querySelectorAll("[data-i18n-aria-label]").forEach((node) => {
    node.setAttribute("aria-label", t(node.dataset.i18nAriaLabel));
  });
}


async function loadApiKeys() {
  const data = await chrome.storage.local.get(["apiKeys", "activeApiKey"]);
  const keys = data.apiKeys || [];
  const activeKey = data.activeApiKey || "";
  
  elements.apiKeySelect.innerHTML = '<option value="">Save locally (Downloads folder)</option>';
  keys.forEach(k => {
    // Support old string format
    const keyString = typeof k === "string" ? k : k.key;
    const keyName = typeof k === "string" ? "API Key" : k.name;
    
    const opt = document.createElement("option");
    opt.value = keyString;
    
    const maskedKey = "************" + keyString.slice(-4);
    opt.textContent = `${keyName} - ${maskedKey}`;
    if (keyString === activeKey) opt.selected = true;
    elements.apiKeySelect.appendChild(opt);
  });
}
